document.getElementById('submitQuiz').addEventListener('click', () => {
    const answers = document.querySelectorAll('input[type="radio"]:checked');

    if (answers.length < 4) {
        alert("Please answer all questions!");
        return;
    }

    const counts = { A: 0, B: 0, C: 0, D: 0 };

    
    answers.forEach(answer => {
        counts[answer.value]++;
    });

    
    let maxCount = 0;
    let resultType = null;

    for (const [key, value] of Object.entries(counts)) {
        if (value > maxCount) {
            maxCount = value;
            resultType = key;
        } else if (value === maxCount) {
            resultType = "Tie";
        }
    }

    const resultText = document.getElementById('resultText');
    if (resultType === "A") {
        resultText.textContent = "Beyaz kedi gibi sakin ve sevilen birisiN";
    } else if (resultType === "B") {
        resultText.textContent = "Cins Kedi saflığı sakinliği var üzerinde";
    } else if (resultType === "C") {
        resultText.textContent = "Tekir gibi yaşam dolu enerjik  keyiflisin.";
    } else if (resultType === "D") {
        resultText.textContent = "Sen Siyah kedi gibi dışarıdan ürkülen ama kendi halinde sakin birisin ";
    } else if (resultType === "Tie") {
        resultText.textContent = "Aslan!! gibi ürkünç güçlü bir insansın";
    }

    document.getElementById('result').classList.remove('hidden');
});
