document.getElementById('submitQuiz').addEventListener('click', () => {
    const answers = document.querySelectorAll('input[type="radio"]:checked');

    if (answers.length < 4) {
        alert("Please answer all questions!");
        return;
    }

    const counts = { A: 0, B: 0, C: 0, D: 0 };

    
    answers.forEach(answer => {
        counts[answer.value]++;
    });

    
    let maxCount = 0;
    let resultType = null;

    for (const [key, value] of Object.entries(counts)) {
        if (value > maxCount) {
            maxCount = value;
            resultType = key;
        } else if (value === maxCount) {
            resultType = "Tie";
        }
    }

    const resultText = document.getElementById('resultText');
    if (resultType === "A") {
        resultText.textContent = "Sen ÇOK kültürlü birisin";
    } else if (resultType === "B") {
        resultText.textContent = "Diyecek sözüm yok";
    } else if (resultType === "C") {
        resultText.textContent = "";
    } else if (resultType === "D") {
        resultText.textContent = "";
    } else if (resultType === "Tie") {
        resultText.textContent = "Daha iyi olabilirdi";
    }

    document.getElementById('result').classList.remove('hidden');
});
