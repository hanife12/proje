document.getElementById('submitQuiz').addEventListener('click', () => {
    const answers = document.querySelectorAll('input[type="radio"]:checked');

    if (answers.length < 4) {
        alert("Please answer all questions!");
        return;
    }

    const counts = { A: 0, B: 0, C: 0, D: 0 };

    
    answers.forEach(answer => {
        counts[answer.value]++;
    });

    
    let maxCount = 0;
    let resultType = null;

    for (const [key, value] of Object.entries(counts)) {
        if (value > maxCount) {
            maxCount = value;
            resultType = key;
        } else if (value === maxCount) {
            resultType = "Tie";
        }
    }

    const resultText = document.getElementById('resultText');
    if (resultType === "A") {
        resultText.textContent = "Senin en kötü özelliğin stresli olman";
    } else if (resultType === "B") {
        resultText.textContent = "Senin en kötü özelliğin hayalperest olman";
    } else if (resultType === "C") {
        resultText.textContent = "Senin en kötü özelliğin sıradan olman";
    } else if (resultType === "D") {
        resultText.textContent = "Senin en kötü özelliğin karamsar olman";
    } else if (resultType === "Tie") {
        resultText.textContent = "Senin herhangi bir kötü özelliğin yok:)) ";
    }

    document.getElementById('result').classList.remove('hidden');
});
