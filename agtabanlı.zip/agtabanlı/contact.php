<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, textarea {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: #ab2666;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #ab2666;
        }
        .success, .error {
            text-align: center;
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color:rgb(225, 72, 192);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Contact Us</h1> 
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            
            $config = [
                'servername' => 'localhost',
                'username' => 'root',
                'password' => '',
                'dbname' => 'contact_form',
            ];

            try {
               
                $dsn = "mysql:host={$config['servername']};dbname={$config['dbname']};charset=utf8mb4";
                $pdo = new PDO($dsn, $config['username'], $config['password']);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                
                $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
                $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                $message = htmlspecialchars($_POST['message'], ENT_QUOTES, 'UTF-8');

               
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('Invalid email format');
                }

                
                $stmt = $pdo->prepare("INSERT INTO contacts (name, email, message) VALUES (:name, :email, :message)");
                $stmt->execute([
                    ':name' => $name,
                    ':email' => $email,
                    ':message' => $message
                ]);

                echo "<div class='success'>Message sent successfully!</div>";

            } catch (PDOException $e) {
                error_log("Database Error: " . $e->getMessage());
                echo "<div class='error'>An error occurred. Please try again later.</div>";
            } catch (Exception $e) {
                echo "<div class='error'>" . htmlspecialchars($e->getMessage()) . "</div>";
            }
        }
        ?>
        
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
            <input type="text" name="name" placeholder="Name" required 
                   maxlength="100" pattern="[A-Za-z0-9\s]+" 
                   title="Please enter a valid name (letters, numbers, and spaces only)">
            
            <input type="email" name="email" placeholder="Email" required maxlength="255">
            
            <textarea name="message" placeholder="Message" rows="5" required maxlength="1000"></textarea>
            
            
            <?php
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $token = bin2hex(random_bytes(32));
            $_SESSION['csrf_token'] = $token;
            ?>
            <input type="hidden" name="csrf_token" value="<?php echo $token; ?>">
            
            <button type="submit">Send</button>
        </form>
    </div>
</body>
</html>